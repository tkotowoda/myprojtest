﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibrary2namespace
{
    public class Createuser
    {


        public long Id { get; set; }
        public string Name { get; set; }
        public string Username { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        public string Phone { get; set; }
        public string Website { get; set; }
        public string Company { get; set; }

    }
}
