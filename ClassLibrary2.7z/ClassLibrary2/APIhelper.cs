﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using Newtonsoft.Json;

namespace ClassLibrary2namespace
{
   public class APIhelper<T>
    {
        public RestClient restClient;
        public RestRequest restRequest;
        public string baseUrl = "https://jsonplaceholder.typicode.com";
        public RestClient Seturl(string endpoint)
        {
            var url = baseUrl + endpoint; ;
            var restClient = new RestClient(url);
            return restClient;
        }
        public RestRequest CreatePoistRequest(string payload)
        {
            var restRequuest = new RestRequest(Method.POST);
            restRequuest.AddHeader("Accept", "applicatrion/json");
            restRequuest.AddParameter("application/json", payload, ParameterType.RequestBody);
            return restRequest;
            
        }
        public RestRequest CreateGettRequest(string payload)
        {
            var restRequest1 = new RestRequest(Method.GET);
            restRequest1.AddHeader("Accept", "applicatrion/json");
            return restRequest1;

        }
        public IRestResponse GetResponse(RestClient client, RestRequest request)
        {
            return client.Execute(request);
        }
        public group GetContent<group>(RestResponse response)
        {
            var content = response.Content;
            group groupobject = JsonConvert.DeserializeObject<group>(content);
            return groupobject;
        }
    }
}
