﻿using ClassLibrary2namespace;

using Newtonsoft.Json;
using RestSharp;
using System;

namespace ClassLibrary2namespace
{
    public class ClassLibrary2
    {
        public  Listoofusers Getusers()
        {
            var restClient = new RestClient("https://jsonplaceholder.typicode.com");
            var RestRequest = new RestRequest("/users", Method.GET);
            RestRequest.AddHeader("Accept", "application/json");
            RestRequest.RequestFormat = DataFormat.Json;

            IRestResponse response = restClient.Execute(RestRequest);
            var content = response.Content;
            content = content.Replace("\n", String.Empty);
            content = content.Replace("[", String.Empty);
            content = content.Replace("]", String.Empty);
            content = content.Replace("\", String.Empty);

            var users = JsonConvert.DeserializeObject<Listoofusers>(content);
            return users;
        }
 /*       public Createuser createusermethod()
        {
            var restClient = new RestClient("https://jsonplaceholder.typicode.com");
            var RestRequest = new RestRequest("users", Method.GET);
            RestRequest.AddHeader("Accept", "application/json");
            RestRequest.RequestFormat = DataFormat.Json;

            IRestResponse response = restClient.Execute(RestRequest);
            var content = response.Content;
            var users = JsonConvert.DeserializeObject<Listoofusers>(content);
            return users;
        }*/
    }
}
